# TempleConnect

TempleConnect is a mobile-friendly browser prototype.

## GitHub Pages
Upload `index.html` to a GitHub repository, then enable:
**Settings → Pages → Deploy from a branch → main → / (root)**

The resulting site can be opened directly in Safari.
